### Hexlet tests and linter status:
[![Actions Status](https://github.com/SizNi/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/SizNi/python-project-49/actions)
### Codeclimat Maintainability Badge:
[![Maintainability](https://api.codeclimate.com/v1/badges/9f4d12ba7f27f2a27bfb/maintainability)](https://codeclimate.com/github/SizNi/python-project-49/maintainability)

### учебный проект Hexlet из 4 текстовых математических игр

### brain-even work video:
[![asciicast](https://asciinema.org/a/527127.svg)](https://asciinema.org/a/527127)
### brain-calc work video:
[![asciicast](https://asciinema.org/a/527156.svg)](https://asciinema.org/a/527156)
### brain-gcd work video:
[![asciicast](https://asciinema.org/a/527197.svg)](https://asciinema.org/a/527197)
### brain-progression work video:
[![asciicast](https://asciinema.org/a/527217.svg)](https://asciinema.org/a/527217)
### brain-prime work video: 
[![asciicast](https://asciinema.org/a/527231.svg)](https://asciinema.org/a/527231)
