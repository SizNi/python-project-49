### Hexlet tests and linter status:
[![Actions Status](https://github.com/SizNi/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/SizNi/python-project-49/actions)
### Codeclimat Maintainability Badge:
[![Maintainability](https://api.codeclimate.com/v1/badges/9f4d12ba7f27f2a27bfb/maintainability)](https://codeclimate.com/github/SizNi/python-project-49/maintainability)
### brain-even work video: https://asciinema.org/a/527127
### brain-calc work video: https://asciinema.org/a/527156
### brain-gcd work video: https://asciinema.org/a/527197
### brain-progression work video: https://asciinema.org/a/527217
### brain-prime work video: https://asciinema.org/a/527231
