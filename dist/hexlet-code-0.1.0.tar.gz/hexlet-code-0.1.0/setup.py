# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:brain_calc',
                     'brain-even = brain_games.scripts.brain_even:brain_even',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Первый проект Hexlet',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/SizNi/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/SizNi/python-project-49/actions)\n### Codeclimat Maintainability Badge:\n[![Maintainability](https://api.codeclimate.com/v1/badges/9f4d12ba7f27f2a27bfb/maintainability)](https://codeclimate.com/github/SizNi/python-project-49/maintainability)\n### brain-even work video: https://asciinema.org/a/7Re3RMnshkiROrpghkRMJdTN8\n',
    'author': 'SizovN',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
