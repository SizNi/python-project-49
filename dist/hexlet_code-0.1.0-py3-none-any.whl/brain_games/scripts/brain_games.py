#!/usr/bin/env python3
from brain_games.scripts.cli import welcome_user


def main():
    print('Welcome to the Brain games!')
    welcome_user()
