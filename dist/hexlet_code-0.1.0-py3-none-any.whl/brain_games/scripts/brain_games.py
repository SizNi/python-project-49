#!/usr/bin/env python3
from brain_games.scripts.cli import get_user_name


def main():
    get_user_name()
