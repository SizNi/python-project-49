#!/usr/bin/env python3
def main():
    print('poetry run brain_games')
    print('Welcome to the Brain games!')
if __name__ == '__main__':
    main()