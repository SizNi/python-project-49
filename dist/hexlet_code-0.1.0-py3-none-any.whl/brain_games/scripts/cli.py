def welcome_user():
    name = prompt.string('whats your name, bro? ')
    print(f'Yo, {name}!')